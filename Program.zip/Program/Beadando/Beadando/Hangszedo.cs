﻿using System;

namespace Beadando
{
    enum Hangszedo
    {
        SSS, SSH, HH, H, HSH, SS
    }
}
